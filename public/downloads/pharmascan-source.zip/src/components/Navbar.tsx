import React, { useState, useEffect } from 'react';
import {
  Camera,
  Search,
  Bell,
  Building2,
  FileText,
  CreditCard,
  TrendingUp,
  AlertTriangle,
  Pill,
  BarChart3,
  Wifi,
  WifiOff,
  Sparkles,
  Smartphone,
  RotateCcw,
} from 'lucide-react';
import { OverallStats, PharmacyUserSession } from '../types/pharmacy';
import { NotificationDrawer } from './notifications/NotificationDrawer';
import { GlobalSearchModal } from './search/GlobalSearchModal';
import { Cloud } from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenScanner: () => void;
  stats: OverallStats | null;
  currentUser?: PharmacyUserSession | null;
  onOpenCloudBackup?: () => void;
  onOpenDiagnostics?: () => void;
  onOpenShareApk?: () => void;
  onOpenDatabaseReset?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenScanner,
  stats,
  currentUser,
  onOpenCloudBackup,
  onOpenDiagnostics,
  onOpenShareApk,
  onOpenDatabaseReset,
}) => {
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showSearch, setShowSearch] = useState(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const totalAlertsCount =
    (stats?.expiredCount || 0) +
    (stats?.criticalExpiryCount || 0) +
    (stats?.priceHikesCount || 0);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'orders', label: 'Smart Orders' },
    { id: 'schedule', label: 'Visits Schedule' },
    { id: 'agencies', label: 'Agencies' },
    { id: 'documents', label: 'Documents' },
    { id: 'payments', label: 'Payments' },
    {
      id: 'price_changes',
      label: 'Price Changes',
      badge: stats?.priceHikesCount ? stats.priceHikesCount : undefined,
      badgeColor: 'bg-red-500/20 text-red-300 border-red-500/30',
    },
    {
      id: 'expiry',
      label: 'Near Expiry',
      badge: stats?.nearExpiryCount ? stats.nearExpiryCount : undefined,
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    },
    { id: 'medicines', label: 'Medicines' },
    { id: 'reports', label: 'Reports' },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16 gap-4">
            {/* Left: Brand Identity */}
            <div
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-3 cursor-pointer group shrink-0"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform">
                <Pill className="w-5 h-5 text-slate-950 rotate-45" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-white font-extrabold text-lg tracking-tight">
                    Pharma<span className="text-emerald-400">Scan</span>
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase tracking-wider">
                    v1.0
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 font-medium">
                  Purchase & Expiry Management Suite
                </div>
              </div>
            </div>

            {/* Center-Right Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => {
                const isActive = currentView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                      isActive
                        ? 'bg-slate-800 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    }`}
                  >
                    <span>{item.label}</span>
                    {item.badge !== undefined && item.badge > 0 && (
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full border ${item.badgeColor}`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Right: Search, Notifications & THE PROMINENT "SCAN BILL" BUTTON */}
            <div className="flex items-center gap-2.5">
              {/* Global Search Trigger (Requirement 17) */}
              <button
                onClick={() => setShowSearch(true)}
                className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-slate-800 transition-colors flex items-center gap-2 text-xs"
                title="Search medicines, bills, batches (Cmd+K)"
              >
                <Search className="w-4 h-4" />
                <span className="hidden xl:inline text-slate-500 font-mono text-[11px]">
                  Search...
                </span>
              </button>

              {/* Offline / Online Indicator (Clickable to open System Diagnostics) */}
              <button
                onClick={onOpenDiagnostics}
                className={`hidden sm:flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-medium border transition-colors cursor-pointer ${
                  isOnline
                    ? 'bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-400 border-emerald-800/40'
                    : 'bg-amber-950/40 hover:bg-amber-900/50 text-amber-400 border-amber-800/40'
                }`}
                title={isOnline ? 'Online • Click for Server Latency & Diagnostics' : 'Offline • Local Database Active (Click for Details)'}
              >
                {isOnline ? <Wifi className="w-3 h-3 text-emerald-400" /> : <WifiOff className="w-3 h-3 text-amber-400" />}
                <span>{isOnline ? 'Sync Ready' : 'Offline Safe'}</span>
              </button>

              {/* Notification Bell */}
              <button
                onClick={() => setShowNotifications(true)}
                className="relative p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl border border-slate-800 transition-colors"
                title="Pharmacy Expiry & Price Alerts"
              >
                <Bell className="w-4 h-4" />
                {totalAlertsCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white font-bold text-[9px] rounded-full flex items-center justify-center animate-pulse">
                    {totalAlertsCount}
                  </span>
                )}
              </button>

              {/* Google Cloud Backup & Account Button (Requirements 4, 5, 25, 26) */}
              {onOpenCloudBackup && (
                <button
                  onClick={onOpenCloudBackup}
                  className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white rounded-xl border border-slate-800 hover:border-teal-500/50 transition-all flex items-center gap-1.5 text-xs cursor-pointer group"
                  title="Google Account & Cloud Backup"
                >
                  <Cloud className="w-4 h-4 text-teal-400 group-hover:scale-110 transition-transform" />
                  <span className="hidden xl:inline text-[11px] font-semibold text-slate-300">
                    {currentUser?.name ? currentUser.name.split(' ')[0] : 'Cloud Sync'}
                  </span>
                </button>
              )}

              {/* Share APK Button (Issue 2) */}
              {onOpenShareApk && (
                <button
                  onClick={onOpenShareApk}
                  className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white rounded-xl border border-slate-800 hover:border-emerald-500/50 transition-all flex items-center gap-1.5 text-xs cursor-pointer group"
                  title="Download & Share APK / Multi-Device App"
                >
                  <Smartphone className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
                  <span className="hidden sm:inline text-[11px] font-semibold text-slate-300">
                    Download &amp; Share APK
                  </span>
                </button>
              )}

              {/* Verified Database Reset Button (Issue 1) */}
              {onOpenDatabaseReset && (
                <button
                  onClick={onOpenDatabaseReset}
                  className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-red-400 rounded-xl border border-slate-800 hover:border-red-500/40 transition-all flex items-center gap-1.5 text-xs cursor-pointer group"
                  title="Reset Database & Clean Start"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-red-400 group-hover:-rotate-90 transition-transform" />
                  <span className="hidden xl:inline text-[11px] font-semibold text-slate-300">
                    Reset
                  </span>
                </button>
              )}

              {/* ============================================================== */}
              {/* THE PROMINENT "SCAN BILL" BUTTON (Requirement 1) */}
              {/* ============================================================== */}
              <button
                onClick={onOpenScanner}
                className="px-4 py-2 bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-emerald-500/25 flex items-center gap-2 transition-all transform active:scale-95 ring-2 ring-emerald-400/40 hover:ring-emerald-300"
              >
                <Camera className="w-4 h-4 stroke-[2.5]" />
                <span>SCAN BILL</span>
              </button>
            </div>
          </div>

          {/* Mobile Secondary Nav */}
          <div className="flex lg:hidden overflow-x-auto py-2 border-t border-slate-800/60 gap-1.5 scrollbar-none items-center">
            {onOpenShareApk && (
              <button
                onClick={onOpenShareApk}
                className="px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap bg-emerald-950/70 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-600/60 flex items-center gap-1 shrink-0"
              >
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Download &amp; Share APK</span>
              </button>
            )}
            {navItems.map((item) => {
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-1 ${
                    isActive
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>{item.label}</span>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className="text-[9px] px-1 rounded-full bg-slate-900 text-white font-bold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Slide-out notification drawer */}
      <NotificationDrawer
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        stats={stats}
        onNavigate={onNavigate}
      />

      {/* Global Search Modal */}
      <GlobalSearchModal
        isOpen={showSearch}
        onClose={() => setShowSearch(false)}
        onSelectAgency={(id) => onNavigate('agencies')}
      />
    </>
  );
};
